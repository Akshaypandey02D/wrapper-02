import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpEvent, HttpEventType } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ArtifactoryService {
  private baseUrl = "https://useapp55824.mhf.mhc/api/v2/workflow_job_templates/28/launch/"; // Use environment variable
  private authToken = "47VMoCUfyXtLZhGA3FBKVrQTOOFQXZ"; 
  private repoKey="aaaaaaaa"

  constructor(private http: HttpClient) { }

  // Helper function to create headers with the auth token
  private getHeaders(): HttpHeaders {
    return new HttpHeaders({
      'Authorization': `Bearer ${this.authToken}` // Use Bearer token for authentication
    });
  }

  // Upload an MSI file to Artifactory
 public  uploadMsiFile(file: File): Observable<HttpEvent<any>> {
    const url = `${this.baseUrl}/storage/${this.repoKey}/${file.name}`;
    const formData = new FormData();
    formData.append('file', file);

    return this.http.post(url, formData, {
      headers: this.getHeaders(),
      reportProgress: true, 
      observe: 'events'   
    });
  }
}