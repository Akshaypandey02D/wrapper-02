import { TestBed } from '@angular/core/testing';

import { ArtifactoryService } from './artifactory.service';

describe('ArtifactoryService', () => {
  let service: ArtifactoryService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ArtifactoryService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
