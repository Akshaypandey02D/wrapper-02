import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DeploymentSectionComponent } from './deployment-section/deployment-section.component';
import { PackageDetectionSectionComponent } from './package-detection-section/package-detection-section.component';
import { AdditionalInfoSectionComponent } from './additional-info-section/additional-info-section.component';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { ApiService } from '../../../service/details.service';
import Swal from 'sweetalert2';

import { MainActionsComponent } from '../main-actions/main-actions.component';
import { ArtifactoryService } from '../../../service/artifactory.service';

interface Field {
  label: string;
  key: string;
  value: string;
}

type Result = {
  install_block?: string;
  uninstall_block?: string;
  repair_block?: string;
};

@Component({
  selector: 'app-general',
  templateUrl: './general.component.html',
  styleUrls: ['./general.component.scss'],
  imports: [ReactiveFormsModule, CommonModule, FormsModule],
  providers: [ApiService,ArtifactoryService],
})
export class GeneralComponent {
  public isModalOpen = false;
  public editForm!: FormGroup;
  public selectedFile: File | null = null;
  public newFileName: string = '';

  fields: Field[] = [
    { label: 'Name', key: 'name', value: 'Gaurav' },
    { label: 'Version', key: 'version', value: '1.1' },
    { label: 'Publisher', key: 'publisher', value: 'S&P' },
    { label: 'Architecture', key: 'architecture', value: 'x86' },
    { label: 'Msi Name', key: 'display name', value: 'Vs.MSI' },
    { label: 'Author', key: 'author', value: 'gaurav.dhyani2@spglobal.com' },
    { label: 'Description', key: 'description', value: 'This is demo' },
  ];

  public deploymentConfig = {
    suppressReboot: true,
    terminalServerMode: false,
    installationMode: 'Interactive',
  };

  public sections = [
    {
      title: 'Install',
      description: 'Actions performed during installation',
      details: ""
    },
    {
      title: 'Uninstall',
      description: 'Actions performed during uninstallation',
      details:""
    },
    {
      title: 'Repair',
      description: 'Actions performed during repair',
      details: '',
    },
  ];

  public packageDetectionType = 'Registry';
  public notes: string = 'this is demo';
  public informationUrl: string = '';

  constructor(private fb: FormBuilder, private apiService: ApiService ,private artifactoryService:ArtifactoryService) {
    this.editForm = this.fb.group(
      this.fields.reduce(
        (
          formControls: { [x: string]: any[] },
          field: { key: string | number; value: any }
        ) => {
          formControls[field.key] = [field.value]; // Initialize each control
          return formControls;
        },
        {}
      )
    );
  }

  public showAlert() {
    Swal.fire('', 'Data has been updated', 'success');
  }
  onNotesUpdated(newNotes: string) {
    this.notes = newNotes;
  }

  onUrlUpdated(newUrl: string) {
    this.informationUrl = newUrl;
  }

  openEditModal() {
    this.isModalOpen = true;
    const patchValues = this.fields.reduce(
      (
        values: { [x: string]: any },
        field: { key: string | number; value: any }
      ) => {
        values[field.key] = field.value;
        return values;
      },
      {}
    );
    this.editForm.patchValue(patchValues);
  }

  closeEditModal() {
    this.isModalOpen = false;
  }

  public submitPPopupFormData() {
    // Update the fields with the new values from the form
    this.fields = this.fields.map((field) => ({
      ...field,
      value: this.editForm.value[field.key],
    }));
    this.closeEditModal();
    this.showAlert();
  }

  public submitData() {
    // Prepare the data to be sent to the API
    const result: Result = this.sections.reduce((acc, item) => {
      acc[`${item.title.toLowerCase()}_block` as keyof Result] = item.details;
      return acc;
    }, {} as Result);

    const mergedObject = { ...result, ...this.editForm.value };
    this.apiService.postAppDetails(mergedObject).subscribe({
      next: (response) => {
        Swal.fire('Success', 'Data has been updated', 'success');
      },
      error: (error) => {
        Swal.fire({
          title: 'Error!',
          text: error.message,
          icon: 'error',
          confirmButtonText: 'OK',
          buttonsStyling: true,
        });
      },
    });
  }

  public handleAddInstaller(sectionTitle: string) {
    alert(`${sectionTitle} installer added`);
  }
 
  public onUploadInstaller(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      const originalFile = input.files[0];
      const originalName = originalFile.name;
      console.log(originalName,"file to be uploadeddddddddd----------------")
      // Create a new File object with the updated name
      this.selectedFile = new File([originalFile], originalName, {
        type: originalFile.type,
        lastModified: originalFile.lastModified
      });

      this.newFileName = originalName; // For display purposes
      this.uploadMsiFile(originalFile,originalName)
      
    }
  }

  public updateDetails(newFileName:string) {
    this.sections.forEach(section => {
      switch (section.title) {
        case 'Install':
          section.details = `Start-ADTMsiProcess -Action 'Install' - Filepath '${newFileName}'`;
          break;
        case 'Uninstall':
          section.details = `Start-ADTMsiProcess -Action 'Uninstall' - Filepath '${newFileName}'`;
          break;
        case 'Repair':
          section.details = `Repair process started for file: ${newFileName}`;
          break;
        default:
          section.details = 'No action defined for this section';
      }
    });
  }

   public uploadMsiFile(file: File,fileUploadedName:string) {
  
    this.artifactoryService.uploadMsiFile(file).subscribe(
      (event: any) => {
       console.log("successs");
       this.updateDetails(fileUploadedName)
      },
      (error: any) => {
        console.error('Error uploading file', error);
        alert('File upload failed. Please try again.');
      }
    );
  }
}
