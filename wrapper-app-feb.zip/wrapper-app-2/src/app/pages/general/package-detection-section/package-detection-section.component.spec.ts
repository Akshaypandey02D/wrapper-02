import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PackageDetectionSectionComponent } from './package-detection-section.component';

describe('PackageDetectionSectionComponent', () => {
  let component: PackageDetectionSectionComponent;
  let fixture: ComponentFixture<PackageDetectionSectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PackageDetectionSectionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PackageDetectionSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
