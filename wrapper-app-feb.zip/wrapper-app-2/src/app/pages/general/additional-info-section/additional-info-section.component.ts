import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-additional-info-section',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './additional-info-section.component.html',
  styleUrls: ['./additional-info-section.component.scss']
})
export class AdditionalInfoSectionComponent {
  @Input() notes!: string;
  @Output() notesChange = new EventEmitter<string>();

  @Input() informationUrl: string = '';
  @Output() informationUrlChange = new EventEmitter<string>();

  onNotesChange(event: Event) {
    const value = (event.target as HTMLInputElement).value;
    this.notesChange.emit(value);
  }

  onUrlChange(event: Event) {
    const value = (event.target as HTMLInputElement).value;
    this.informationUrlChange.emit(value);
  }
}
