import { Component } from '@angular/core';

@Component({
  selector: 'app-pre-actions',
  imports: [],
  templateUrl: './pre-actions.component.html',
  styleUrl: './pre-actions.component.scss'
})
export class PreActionsComponent {

}
