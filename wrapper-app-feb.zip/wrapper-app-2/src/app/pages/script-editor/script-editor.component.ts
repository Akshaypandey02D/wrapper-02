import { Component } from '@angular/core';

@Component({
  selector: 'app-script-editor',
  imports: [],
  templateUrl: './script-editor.component.html',
  styleUrl: './script-editor.component.scss'
})
export class ScriptEditorComponent {

}
