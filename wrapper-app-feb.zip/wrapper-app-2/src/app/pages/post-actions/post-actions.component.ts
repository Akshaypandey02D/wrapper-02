import { Component } from '@angular/core';

@Component({
  selector: 'app-post-actions',
  imports: [],
  templateUrl: './post-actions.component.html',
  styleUrl: './post-actions.component.scss'
})
export class PostActionsComponent {

}
