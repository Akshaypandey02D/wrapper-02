import { Component } from '@angular/core';

@Component({
  selector: 'app-upgrade',
  imports: [],
  templateUrl: './upgrade.component.html',
  styleUrl: './upgrade.component.scss'
})
export class UpgradeComponent {

}
